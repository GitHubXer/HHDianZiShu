//
//  DataBaseManager.swift
//  CoreDataDemo
//
//  Created by Tom on 2017/2/4.
//  Copyright © 2017年 Tom. All rights reserved.
//

import UIKit
import CoreData

class DataBaseManager: NSObject {
    
    private let TableNamePerson = "CDPerson"
    private let TableNameBankCard = "CDBankCard"
    
    private lazy var applicationDocumentsDirectory: URL = {
        let urls = Foundation.FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return urls[urls.count-1]
    }()
    
    private lazy var managedObjectModel: NSManagedObjectModel = {
        let modelURL = Bundle.main.url(forResource: "MyDataBase", withExtension: "momd")!
        return NSManagedObjectModel(contentsOf: modelURL)!
    }()
    
    private lazy var persistentStoreCoordinator: NSPersistentStoreCoordinator = {
        let coordinator = NSPersistentStoreCoordinator(managedObjectModel: self.managedObjectModel)
        let url = self.applicationDocumentsDirectory.appendingPathComponent("MyDataBase.sqlite")
        var failureReason = "There was an error creating or loading the application's saved data."
        
        let options = [NSMigratePersistentStoresAutomaticallyOption: NSNumber(value: true as Bool), NSInferMappingModelAutomaticallyOption: NSNumber(value: true as Bool)]
        
        do {
            try coordinator.addPersistentStore(ofType: NSSQLiteStoreType, configurationName: nil, at: url, options: options)
        } catch {
            var dict = [String: AnyObject]()
            dict[NSLocalizedDescriptionKey] = "Failed to initialize the application's saved data" as AnyObject?
            dict[NSLocalizedFailureReasonErrorKey] = failureReason as AnyObject?
            
            dict[NSUnderlyingErrorKey] = error as NSError
            let wrappedError = NSError(domain: "YOUR_ERROR_DOMAIN", code: 9999, userInfo: dict)
            NSLog("Unresolved error \(wrappedError), \(wrappedError.userInfo)")
            //abort()
        }
        
        return coordinator
    }()
    
    private lazy var managedObjectContext: NSManagedObjectContext = {
        let coordinator = self.persistentStoreCoordinator
        var managedObjectContext = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
        managedObjectContext.persistentStoreCoordinator = coordinator
        return managedObjectContext
    }()
    
    private func saveContext () {
        if managedObjectContext.hasChanges {
            do {
                try managedObjectContext.save()
            } catch {
                let nserror = error as NSError
                NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
                //abort()
            }
        }
    }
    
    open static let sharedManager = DataBaseManager()
    
    open func personArray() -> Array<CDPerson>? {
        let fetchRequest: NSFetchRequest<CDPerson> = CDPerson.fetchRequest()
        var fetchedObjects: Array<AnyObject>?
        do {
            try (fetchedObjects = managedObjectContext.fetch(fetchRequest))
        } catch {
            return nil
        }

        if (fetchedObjects != nil) && (fetchedObjects!.count > 0) {
            return fetchedObjects! as? Array<CDPerson>
        } else {
            return nil
        }
    }
    
    open func addPerson(idCardNumber: String, name: String, thumbnailImage: UIImage) -> CDPerson? {
        var result: CDPerson?
        if person(idCardNumber: idCardNumber) == nil {
            if let person = NSEntityDescription.insertNewObject(forEntityName: TableNamePerson, into: managedObjectContext) as? CDPerson {
                person.idCardNumber = idCardNumber
                person.name = name
                if let imageData = UIImageJPEGRepresentation(thumbnailImage, 1.0) {
                    person.thumbnail = imageData as NSData
                }
                saveContext()
                result = person
            }
        }
        return result
    }
    
    open func removePerson(idCardNumber: String) -> Bool {
        var result = false
        if let person = person(idCardNumber: idCardNumber) {
            managedObjectContext.delete(person)
            saveContext()
            result = true
        }
        return result
    }
    
    open func removePerson(person: CDPerson) {
        managedObjectContext.delete(person)
        saveContext()
    }
    
    open func updatePerson(idCardNumber: String, newName: String) -> Bool {
        var result = false
        if let person = person(idCardNumber: idCardNumber) {
            updatePerson(person: person, newName: newName)
            result = true
        }
        return result
    }
    
    open func updatePerson(person: CDPerson, newName: String) {
        person.name = newName
        saveContext()
    }
    
    open func person(idCardNumber: String) -> CDPerson? {
        let fetchRequest: NSFetchRequest<CDPerson> = CDPerson.fetchRequest()
        let predicate = NSPredicate(format: "idCardNumber == %@", idCardNumber)
        fetchRequest.predicate = predicate
        var fetchedObjects: Array<AnyObject>?
        do {
            try (fetchedObjects = managedObjectContext.fetch(fetchRequest))
        } catch {
            return nil
        }
        
        if (fetchedObjects != nil) && (fetchedObjects!.count > 0) {
            return fetchedObjects!.last as? CDPerson
        } else {
            return nil
        }
    }
    
    open func bankCard(idCardNumber: String, bankCardNumber: String) -> CDBankCard? {
        var result: CDBankCard?
        
        if let person = person(idCardNumber: idCardNumber) {
            if person.bankCardList != nil {
                for bankCardObj in person.bankCardList! {
                    if let bankCard = bankCardObj as? CDBankCard {
                        if bankCard.number == bankCardNumber {
                            result = bankCard
                            break
                        }
                    }
                }
            }
        }
        
        return result
    }
    
    open func bankCard(person: CDPerson, bankCardNumber: String) -> CDBankCard? {
        var result: CDBankCard?
        
        if person.bankCardList != nil {
            for bankCardObj in person.bankCardList! {
                if let bankCard = bankCardObj as? CDBankCard {
                    if bankCard.number == bankCardNumber {
                        result = bankCard
                        break
                    }
                }
            }
        }
        
        return result
    }
    
    func bankCardArray(person: CDPerson) -> Array<CDBankCard> {
        var result = [CDBankCard]()
        
        if let bankCardSet = person.bankCardList as? Set<CDBankCard>  {
            for bankCard in bankCardSet {
                result.append(bankCard)
            }
        }
        
        return result
    }
    
    open func addBankCard(idCardNumber: String, bankCardNumber: String, bankName: String) -> Bool {
        var result = false
        
        if let person = person(idCardNumber: idCardNumber) {
            result = addBankCard(person: person, bankCardNumber: bankCardNumber, bankName: bankName)
        }
        
        return result
    }
    
    open func addBankCard(person: CDPerson, bankCardNumber: String, bankName: String) -> Bool {
        var result = false
        
        if bankCard(person: person, bankCardNumber: bankCardNumber) == nil {
            if let bankCard = NSEntityDescription.insertNewObject(forEntityName: TableNameBankCard, into: managedObjectContext) as? CDBankCard {
                bankCard.bankName = bankName
                bankCard.number = bankCardNumber
                bankCard.person = person
                person.addToBankCardList(bankCard)
                saveContext()
                result = true
            }
        }
        
        return result
    }
    
    open func removeBankCard(idCardNumber: String, bankCardNumber: String) -> Bool {
        var result = false
        
        if let person = person(idCardNumber: idCardNumber) {
            result = removeBankCard(person: person, bankCardNumber: bankCardNumber)
        }
        
        return result
    }
    
    open func removeBankCard(person: CDPerson, bankCardNumber: String) -> Bool {
        var result = false
        
        if let bankCard = bankCard(person: person, bankCardNumber: bankCardNumber) {
            result = removeBankCard(person: person, bankCard: bankCard)
        }
        
        return result
    }
    
    open func removeBankCard(person: CDPerson, bankCard: CDBankCard) -> Bool {
        let result = true
        
        person.removeFromBankCardList(bankCard)
        saveContext()
        
        return result
    }
    
    func updateBankCard(idCardNumber: String, bankCardNumber: String, newBankName: String) -> Bool {
        var result = false
        
        if let person = person(idCardNumber: idCardNumber) {
            result = updateBankCard(person: person, bankCardNumber: bankCardNumber, newBankName: newBankName)
        }
        
        return result
    }
    
    func updateBankCard(person: CDPerson, bankCardNumber: String, newBankName: String) -> Bool {
        var result = false
        
        if let bankCard = bankCard(person: person, bankCardNumber: bankCardNumber) {
            updateBankCard(bankCard: bankCard, newBankName: newBankName)
            result = true
        }
        
        return result
    }
    
    func updateBankCard(bankCard: CDBankCard, newBankName: String) {
        bankCard.bankName = newBankName
        saveContext()
    }
    
}
