//
//  ViewController.swift
//  CoreDataDemo
//
//  Created by Tom on 2017/2/4.
//  Copyright © 2017年 Tom. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    let ShowBankCardViewControllerSBID = "ShowBankCardViewControllerSBID"
    
    var personArray: Array<CDPerson>?
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refresh()
    }
    
    func refresh() {
        personArray = DataBaseManager.sharedManager.personArray()
        tableView.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return personArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellID = "PersonCellID"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellID)
        if cell == nil {
            cell = UITableViewCell(style: .value1, reuseIdentifier: cellID)
        }
        cell?.accessoryType = .detailDisclosureButton
        cell?.textLabel?.text = personArray?[indexPath.row].idCardNumber
        cell?.detailTextLabel?.text = personArray?[indexPath.row].name
        if let data = personArray?[indexPath.row].thumbnail {
            cell?.imageView?.image = UIImage(data: data as Data)
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            DataBaseManager.sharedManager.removePerson(person: personArray![indexPath.row])
            personArray?.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .none)
            refresh()
        }
    }
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        let alert = UIAlertController(title: "修改名字", message: personArray![indexPath.row].idCardNumber, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "取消", style: UIAlertActionStyle.cancel, handler: nil)
        let okAction = UIAlertAction(title: "保存", style: UIAlertActionStyle.default) { [unowned self] (alertAction: UIAlertAction) in
            let person = self.personArray![indexPath.row]
            DataBaseManager.sharedManager.updatePerson(person: person, newName: alert.textFields?.first?.text ?? "")
            self.refresh()
        }
        alert.addTextField { [unowned self] (textField: UITextField) in
            textField.text = self.personArray![indexPath.row].name
        }
        alert.addAction(cancelAction)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: ShowBankCardViewControllerSBID, sender: indexPath)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == ShowBankCardViewControllerSBID {
            let vc = segue.destination as! BankCardViewController
            vc.person = personArray![(sender as! IndexPath).row]
        }
    }
}

