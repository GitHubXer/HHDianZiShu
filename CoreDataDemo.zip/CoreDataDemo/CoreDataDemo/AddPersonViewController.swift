//
//  AddPersonViewController.swift
//  CoreDataDemo
//
//  Created by Tom on 2017/2/6.
//  Copyright © 2017年 Tom. All rights reserved.
//

import UIKit

class AddPersonViewController: UIViewController {

    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet weak var contentViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var idCardTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        IQKeyboardManager.sharedManager().toolbarTintColor = UIColor.blue
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        contentViewHeight.constant = scrollView.frame.height - 64
    }

    @IBAction func save(_ sender: UIBarButtonItem) {
        if let idCardNumber = idCardTextField.text {
            if let name = nameTextField.text {
                let _ = DataBaseManager.sharedManager.addPerson(idCardNumber: idCardNumber, name: name)
                let _ = navigationController?.popViewController(animated: true)
            }
        }
    }
}
