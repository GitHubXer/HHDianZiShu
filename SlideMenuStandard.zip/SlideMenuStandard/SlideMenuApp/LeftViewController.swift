//
//  LeftViewController.swift
//  SlideMenuApp
//
//  Created by Tom on 2016/12/16.
//  Copyright © 2016年 Tom. All rights reserved.
//

import UIKit

enum LeftMenu: Int {
    case main = 0
    case cPlusPlus
    case objectiveC
    case noMenu
}

protocol LeftMenuProtocol : class {
    func changeViewController(_ menu: LeftMenu)
}

class LeftViewController: UIViewController, LeftMenuProtocol {
    
    var mainViewControllerNav: UINavigationController!
    var cPlusPlusViewControllerNav: UINavigationController!
    var nonMenuViewController: NonMenuViewController!

    override func viewDidLoad() {
        super.viewDidLoad()

        let cPlusPlusStoryboard = UIStoryboard(name: "CPlusPlus", bundle: nil)
        cPlusPlusViewControllerNav = cPlusPlusStoryboard.instantiateViewController(withIdentifier: "CPlusPlusViewControllerNav") as! UINavigationController
        
        let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
        nonMenuViewController = mainStoryboard.instantiateViewController(withIdentifier: "NonMenuViewController") as! NonMenuViewController
        nonMenuViewController.delegate = self
    }
    
    func mainViewController() -> MainViewController? {
        var result: MainViewController?
        for viewController in mainViewControllerNav.viewControllers {
            if viewController is MainViewController {
                result = viewController as? MainViewController
                break
            }
        }
        return result
    }
    
    func changeViewController(_ menu: LeftMenu) {
        switch menu {
        case .main:
            slideMenuController()?.changeMainViewController(mainViewControllerNav, close: true)
        case .cPlusPlus:
            slideMenuController()?.changeMainViewController(cPlusPlusViewControllerNav, close: true)
        case .objectiveC:
            slideMenuController()?.changeMainViewController(mainViewControllerNav, close: true)
            if let mainViewController = mainViewController() {
                mainViewController.performSegue(withIdentifier: "ShowObjectiveCViewControllerSBID", sender: nil)
            }
        case .noMenu:
            slideMenuController()?.changeMainViewController(nonMenuViewController, close: true)
        }
    }

    @IBAction func showCPlusPlus(_ sender: UIButton) {
        changeViewController(.cPlusPlus)
    }
    
    @IBAction func showObjectiveC(_ sender: UIButton) {
        changeViewController(.objectiveC)

    }
    
    @IBAction func showMain(_ sender: UIButton) {
        changeViewController(.main)
    }
    
    @IBAction func showNoMenu(_ sender: UIButton) {
        changeViewController(.noMenu)
    }
}
