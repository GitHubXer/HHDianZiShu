//
//  NoBackTitleNavigationBar.swift
//  SlideMenuStandard
//
//  Created by Tom on 2016/12/16.
//  Copyright © 2016年 Tom. All rights reserved.
//

import UIKit

class NoBackTitleNavigationBar: UINavigationBar {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
}
