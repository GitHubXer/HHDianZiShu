//
//  NonMenuViewController.swift
//  SlideMenuApp
//
//  Created by Tom on 2016/12/16.
//  Copyright © 2016年 Tom. All rights reserved.
//

import UIKit

class NonMenuViewController: UIViewController {
    
    weak var delegate: LeftMenuProtocol?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func showMain(_ sender: UIButton) {
        delegate?.changeViewController(LeftMenu.main)
    }
}
