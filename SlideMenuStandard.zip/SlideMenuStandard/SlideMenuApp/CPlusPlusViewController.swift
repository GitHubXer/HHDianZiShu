//
//  CPlusPlusViewController.swift
//  SlideMenuApp
//
//  Created by Tom on 2016/12/16.
//  Copyright © 2016年 Tom. All rights reserved.
//

import UIKit

class CPlusPlusViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func showLeftMenu(_ sender: Any) {
        slideMenuController()?.toggleLeft()
    }
    
    @IBAction func showRightMenu(_ sender: Any) {
        slideMenuController()?.toggleRight()
    }
    

}
