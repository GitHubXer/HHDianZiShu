//
//  SwiftViewController.swift
//  SlideMenuApp
//
//  Created by Tom on 2016/12/16.
//  Copyright © 2016年 Tom. All rights reserved.
//

import UIKit

class SwiftViewController: UIViewController {

    @IBOutlet weak var editBarButtonItem: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        navigationItem.title = "Swift 3.0.1";
        editBarButtonItem.tintColor = UIColor.green
    }
    
    func back(sender: Any) {
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    @IBAction func editClicked(_ sender: UIBarButtonItem) {
        isEditing = !isEditing
        if isEditing {
            editBarButtonItem.title = "完成"
            editBarButtonItem.tintColor = UIColor.cyan
        } else {
            editBarButtonItem.title = "编辑"
            editBarButtonItem.tintColor = UIColor.green
        }
    }
}
